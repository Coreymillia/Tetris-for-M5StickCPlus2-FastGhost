# 🎮 TETЯIS Ultimate Edition v1.5.0 for M5StickC Plus 2

**The most advanced handheld Tetris experience ever created** - Multi-functional gaming device with Tetris, WiFi tools, and professional-grade features for the M5StickC Plus 2.

![M5StickC Plus 2](https://img.shields.io/badge/Device-M5StickC%20Plus%202-blue)
![Platform](https://img.shields.io/badge/Platform-ESP32-green)
![License](https://img.shields.io/badge/License-MIT-yellow)
![Version](https://img.shields.io/badge/Version-v1.5.0-brightgreen)

## 🚀 Revolutionary Features

### 🎯 **Professional Tetris Experience**
- **🎮 Level Selection System** - Choose starting difficulty (0-9) with dramatic speed differences
- **👻 Ghost Piece Preview** - Professional-grade piece placement visualization
- **⚡ Ultra-Fast Gameplay** - Speed range from 1000ms (beginner) to 100ms (insane)
- **🚀 Seamless Progression** - Dynamic speed increases with no interruptions
- **🎨 Clean Visuals** - Smooth animations and professional UI

### 📡 **Advanced WiFi Tools**
- **📊 WiFi Signal Scanner** - Real-time network analyzer with signal strength visualization
- **📶 Bruce-Style Beacon Spam** - Create fake TETЯIS-themed WiFi networks
- **🔍 Network Analysis** - Security types, signal quality, and channel usage
- **⚡ Fast Navigation** - Optimized controls for smooth WiFi scanning

### 🎛️ **Multi-Mode Operation**
- **🎮 Tetris Mode** - Press M5 button (default)
- **📡 WiFi Beacon** - Hold L+R buttons at startup
- **📊 WiFi Scanner** - Hold joystick UP at startup

## 🎯 Gameplay Controls

### MiniJoyC Hat (Recommended)
- **🕹️ Hat Up:** Fast Drop / Navigate scanner
- **🔘 Hat Button:** Rotate Right  
- **🕹️ Hat Left/Right:** Move piece horizontally / Navigate levels
- **🕹️ Hat Down:** Soft drop / Navigate scanner

### Built-in Buttons
- **📱 Left Button (GPIO 35):** Rotate left / Decrease level
- **📱 M5 Button (GPIO 37):** Pause/Resume / Exit modes / Confirm
- **📱 Right Button (GPIO 39):** Reset game / Increase level

## 🎮 Level Selection System

Choose your challenge level at game start:

| Level | Speed | Difficulty | Description |
|-------|--------|------------|-------------|
| **0** | 1000ms | **Beginner** | Perfect for learning |
| **1** | 800ms | **Beginner** | Comfortable pace |
| **2** | 600ms | **Intermediate** | Getting serious |
| **3** | 450ms | **Intermediate** | Real challenge |
| **4** | 350ms | **Advanced** | Expert level |
| **5** | 300ms | **Advanced** | Very fast |
| **6** | 250ms | **Expert** | Pro speed |
| **7** | 200ms | **Expert** | Lightning fast |
| **8** | 150ms | **Expert** | Near impossible |
| **9** | 100ms | **INSANE** | Humanly impossible? |

## 👻 Ghost Piece Feature

Professional-grade piece preview system:
- **📍 Perfect Positioning** - See exactly where pieces will land
- **🎯 Strategic Planning** - Plan multi-line clears easily
- **⚡ Real-time Updates** - Ghost moves with piece rotation/movement
- **🎨 Clean Visuals** - Subtle gray outline, no trails or artifacts

## 📊 WiFi Scanner Features

Advanced network analysis tool:
- **🔍 Real-time Scanning** - Updates every 2 seconds
- **📶 Signal Visualization** - Color-coded strength bars (Green=Strong, Red=Weak)
- **🔒 Security Analysis** - Shows encryption types (OPEN, WPA2, WPA3)
- **📋 Sorted Display** - Networks ordered by signal strength
- **⚡ Fast Navigation** - Smooth up/down browsing

## 📡 WiFi Beacon Networks

Bruce-inspired fake network creation:
- `TETЯIS_▣NODE_003` - Gaming-themed networks
- `BRUᄃE_TETЯIS_ΞXPT` - Hacker aesthetics  
- `TETЯIS_🧱_INJECT0R` - Creative variations
- `CHAOS_BЯICKS_⚡` - And many more!

## 🚀 Quick Start

### Method 1: M5Burner (Easiest)
1. Download `TETRIS_Enhanced_v1.5.0.bin`
2. Flash using M5Burner to your M5StickC Plus 2
3. Enjoy!

### Method 2: PlatformIO
1. Clone this repository
2. Open in PlatformIO
3. Connect your M5StickC Plus 2
4. Run `pio run --target upload`

## 📋 Hardware Requirements

- **M5StickC Plus 2** (ESP32-PICO-D4)
- **MiniJoyC Hat** (optional but highly recommended)
- **USB-C Cable** for programming and power

## 🎯 Game Modes

### 🎮 Tetris Game Mode
**How to access:** Press M5 button at startup

Features:
- Level selection screen with L/R buttons
- Ghost piece preview for perfect placement
- Progressive speed increase as you clear lines
- Professional scoring and level system

### 📡 WiFi Beacon Mode  
**How to access:** Hold both side buttons (L+R) at startup

Features:
- Broadcasts fake TETЯIS-themed networks
- Cycles through creative network names
- Press M5 to exit back to main menu

### 📊 WiFi Scanner Mode
**How to access:** Hold joystick UP at startup  

Features:
- Real-time network discovery
- Signal strength visualization
- Security type analysis
- Navigate with Up/Down, M5 to exit

## ⚡ Performance Stats

- **Memory Usage:** 75% Flash, 14.8% RAM
- **Speed Range:** 1000ms → 100ms (10x speed difference!)
- **Network Scan:** Every 2 seconds
- **Ghost Piece:** Real-time calculation
- **Smooth 60fps** gameplay on all modes

## 🏆 What Makes This Special

This isn't just Tetris - it's a **complete handheld gaming and network analysis platform**:

✅ **Professional Tetris** - Ghost piece, level selection, perfect controls  
✅ **Network Tools** - WiFi scanner and beacon spam capabilities  
✅ **Ultra-Fast Gameplay** - From beginner to impossibly fast speeds  
✅ **Clean Interface** - No lag, no artifacts, smooth animations  
✅ **Multi-Functional** - Three distinct modes in one device  

## 🛠️ Technical Details

- **Platform:** ESP32-PICO-D4 (M5StickC Plus 2)
- **Framework:** Arduino with PlatformIO
- **Display:** 135x240 TFT optimized rendering
- **Memory:** Efficient algorithms, minimal RAM usage
- **WiFi:** Dual-mode scanning and broadcast capabilities
- **Controls:** Multi-input support (buttons + joystick)

## 📝 Version History

- **v1.5.0** - Added professional ghost piece preview system
- **v2.0.0** - Major speed system overhaul, level selection
- **v1.9.x** - WiFi scanner integration and optimization  
- **v1.8.0** - Added WiFi signal strength scanner
- **v1.7.0** - Enhanced WiFi beacon functionality

## 🎯 Perfect For

- **🎮 Gaming Enthusiasts** - Ultimate portable Tetris experience
- **🔧 Network Professionals** - Handheld WiFi analysis tool
- **🎓 Learning** - Gradual difficulty progression system  
- **🏆 Competitions** - Consistent, fast gameplay
- **👥 Social** - Show off the impossible Level 9 speed!

---

**Download the latest release and experience the most advanced handheld Tetris ever created!** 🚀🎮👻

## 🛠️ Mode Selection

At startup, choose your mode:

### WiFi Beacon Mode
Hold **both side buttons (L+R)** at startup for 0.5 seconds to activate WiFi beacon spam mode.

### WiFi Scanner Mode  
Hold **joystick UP** at startup for 0.5 seconds to activate WiFi signal strength scanner (NEW!)

### Tetris Game Mode
Simply press the **M5 button** to start the game.

## 📊 WiFi Scanner Features

The new WiFi scanner provides:
- **Real-time Network Discovery** - Scans for nearby WiFi networks every 2 seconds
- **Signal Strength Visualization** - Color-coded signal bars (Green=Excellent, Yellow=Fair, Red=Poor)
- **Security Analysis** - Shows encryption type for each network (OPEN, WPA2, WPA3, etc.)
- **Sorted Display** - Networks automatically sorted by signal strength
- **Navigation** - Use joystick Up/Down to select networks, M5 button to exit

## 📡 Custom TETЯIS Beacon Networks

When in beacon mode, the device broadcasts creative network names including:
- `TETЯIS_▣NODE_003`
- `BRUᄃE_TETЯIS_ΞXPT`
- `TETЯIS_🧱_INJECT0R`
- `TETЯIS_💥_BЯOADCAST`
- `STACK_OVEЯFLOW_☠`
- `TETЯIS_🧠_GLYPH_003`
- `CHAOS_BЯICKS_⚡`
- And many more creative variations...

## 📋 Hardware Requirements

- **M5StickC Plus 2** (ESP32-PICO-D4)
- **MiniJoyC Hat** (optional but highly recommended for best gameplay experience)
- **USB-C Cable** for programming and power

## 📦 Installation Methods

### Method 1: M5Burner (Easiest)
1. Download M5Burner from [M5Stack official site](https://m5stack.com/pages/download)
2. Use the pre-built package in `/m5burner_package/TETRIS_WiFi_Beacon_v1.0.0.zip`
3. Flash directly to your M5StickC Plus 2

### Method 2: PlatformIO (For Developers)
```bash
# Clone the repository
git clone https://github.com/coreymillia/Tetris-for-M5StickCPlus2.git
cd Tetris-for-M5StickCPlus2

# Install PlatformIO if not already installed
pip install platformio

# Build and flash
pio run --target upload
```

### Method 3: Manual Flash (Advanced)
```bash
# Make the flash script executable and run
chmod +x flash.sh
./flash.sh
```

## 🛠️ Development

This project is built with:
- **PlatformIO** - Modern embedded development platform
- **M5Unified Library** - Latest M5Stack unified library
- **Custom Tetris Engine** - Optimized for small displays
- **WiFi Beacon Implementation** - Custom ESP32 WiFi management

### Project Structure
```
├── src/                    # Source code
│   ├── main.cpp           # Main application
│   ├── tet.h              # Tetris game logic
│   ├── wifi_beacon.h/.cpp # WiFi beacon functionality
│   └── UNIT_MiniJoyC.h/.cpp # Joystick support
├── m5burner_package/      # Ready-to-flash M5Burner package
├── platformio.ini         # PlatformIO configuration
├── flash.sh              # Direct flashing script
└── README.md             # This file
```

## 🎨 Gameplay Screenshots

*Game features a clean, retro-styled interface optimized for the small M5StickC Plus 2 display*

## 🤝 Contributing

We welcome contributions! Whether it's:
- 🐛 Bug fixes
- ✨ New features 
- 📝 Documentation improvements
- 🎮 Gameplay enhancements

Please feel free to open issues or submit pull requests.

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- **Original Tetris Implementation** - [AleksAlcDel](https://github.com/AleksAlcDel/Tetris-for-M5StickCPlus2)
- **Classic Tetris Concept** - Alexey Pajitnov
- **M5Stack Community** - For amazing hardware and libraries
- **Bruce Firmware** - Inspiration for WiFi beacon functionality
- **Enhanced Version** - coreymillia & GitHub Copilot

## 📞 Support

If you encounter any issues:
1. Check the [Issues](https://github.com/coreymillia/Tetris-for-M5StickCPlus2/issues) page
2. Create a new issue with detailed description
3. Join M5Stack community discussions

---

**Enjoy your enhanced TETЯIS experience! 🎮**

*Made with ❤️ for the M5Stack community*